//
//  CSV_ImportApp.swift
//  CSV Import
//
//  Created by Matthias Deuschl on 23.12.21.
//

import SwiftUI

@main
struct CSV_ImportApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
